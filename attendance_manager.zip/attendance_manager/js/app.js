const STORAGE_KEY = "basicAttendanceManager_v1";

const studentForm = document.getElementById("studentForm");
const studentNameInput = document.getElementById("studentName");
const rollNumberInput = document.getElementById("rollNumber");
const attendanceDateInput = document.getElementById("attendanceDate");
const attendanceTableBody = document.getElementById("attendanceTableBody");
const summaryTableBody = document.getElementById("summaryTableBody");
const formMessage = document.getElementById("formMessage");
const attendanceMessage = document.getElementById("attendanceMessage");
const emptyMessage = document.getElementById("emptyMessage");
const searchInput = document.getElementById("searchInput");

const editDialog = document.getElementById("editDialog");
const editForm = document.getElementById("editForm");
const editNameInput = document.getElementById("editName");
const editRollInput = document.getElementById("editRoll");
const cancelEditButton = document.getElementById("cancelEdit");

let students = loadStudents();
let editingStudentId = null;

attendanceDateInput.value = getTodayDate();
render();

function getTodayDate() {
  const now = new Date();
  const localDate = new Date(now.getTime() - now.getTimezoneOffset() * 60000);
  return localDate.toISOString().slice(0, 10);
}

function loadStudents() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    const parsed = saved ? JSON.parse(saved) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch (error) {
    console.error("Could not load attendance data:", error);
    return [];
  }
}

function saveStudents() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(students));
  } catch (error) {
    alert("Could not save data in this browser. Check your browser storage settings.");
  }
}

function makeId() {
  return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  })[character]);
}

studentForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const name = studentNameInput.value.trim();
  const roll = rollNumberInput.value.trim();

  if (!name || !roll) return;

  const duplicate = students.some(
    (student) => student.roll.toLowerCase() === roll.toLowerCase()
  );
  if (duplicate) {
    formMessage.textContent = "That roll number already exists. Please use a unique roll number.";
    return;
  }

  students.push({
    id: makeId(),
    name,
    roll,
    attendance: {}
  });

  saveStudents();
  studentForm.reset();
  formMessage.textContent = "Student added successfully.";
  render();
  studentNameInput.focus();
});

attendanceDateInput.addEventListener("change", () => {
  attendanceMessage.textContent = "";
  renderAttendanceTable();
});

searchInput.addEventListener("input", renderSummaryTable);

attendanceTableBody.addEventListener("change", (event) => {
  const select = event.target.closest("select[data-student-id]");
  if (!select) return;

  const student = students.find((item) => item.id === select.dataset.studentId);
  const date = attendanceDateInput.value;
  if (!student || !date) return;

  student.attendance = student.attendance || {};
  student.attendance[date] = select.value;
  saveStudents();
  attendanceMessage.textContent = `Attendance saved for ${date}.`;
  renderSummaryTable();
  renderAttendanceTable();
});

summaryTableBody.addEventListener("click", (event) => {
  const button = event.target.closest("button[data-action]");
  if (!button) return;

  const student = students.find((item) => item.id === button.dataset.id);
  if (!student) return;

  if (button.dataset.action === "edit") {
    editingStudentId = student.id;
    editNameInput.value = student.name;
    editRollInput.value = student.roll;
    editDialog.showModal();
  }

  if (button.dataset.action === "delete") {
    const confirmed = confirm(`Delete ${student.name} and all of their attendance records?`);
    if (!confirmed) return;
    students = students.filter((item) => item.id !== student.id);
    saveStudents();
    render();
  }
});

editForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const student = students.find((item) => item.id === editingStudentId);
  if (!student) return;

  const name = editNameInput.value.trim();
  const roll = editRollInput.value.trim();
  if (!name || !roll) return;

  const duplicate = students.some(
    (item) => item.id !== student.id && item.roll.toLowerCase() === roll.toLowerCase()
  );
  if (duplicate) {
    alert("That roll number is already used by another student.");
    return;
  }

  student.name = name;
  student.roll = roll;
  saveStudents();
  editDialog.close();
  editingStudentId = null;
  render();
});

cancelEditButton.addEventListener("click", () => {
  editDialog.close();
  editingStudentId = null;
});

function getCounts(student) {
  const records = Object.values(student.attendance || {});
  const present = records.filter((status) => status === "Present").length;
  const absent = records.filter((status) => status === "Absent").length;
  const total = present + absent;
  const percentage = total ? (present / total) * 100 : 0;
  return { present, absent, total, percentage };
}

function render() {
  renderAttendanceTable();
  renderSummaryTable();
}

function renderAttendanceTable() {
  if (students.length === 0) {
    attendanceTableBody.innerHTML = '<tr><td colspan="4">No students added yet.</td></tr>';
    return;
  }

  const date = attendanceDateInput.value;
  attendanceTableBody.innerHTML = students
    .slice()
    .sort((a, b) => a.roll.localeCompare(b.roll, undefined, { numeric: true }))
    .map((student) => {
      const currentStatus = (student.attendance || {})[date] || "";
      return `
        <tr>
          <td>${escapeHtml(student.roll)}</td>
          <td>${escapeHtml(student.name)}</td>
          <td>
            <select data-student-id="${escapeHtml(student.id)}" aria-label="Attendance for ${escapeHtml(student.name)}">
              <option value="" ${currentStatus === "" ? "selected" : ""}>Not marked</option>
              <option value="Present" ${currentStatus === "Present" ? "selected" : ""}>Present</option>
              <option value="Absent" ${currentStatus === "Absent" ? "selected" : ""}>Absent</option>
            </select>
          </td>
          <td><span class="${currentStatus === "Present" ? "status-present" : currentStatus === "Absent" ? "status-absent" : ""}">${currentStatus || "—"}</span></td>
        </tr>`;
    }).join("");
}

function renderSummaryTable() {
  const query = searchInput.value.trim().toLowerCase();
  const filtered = students.filter((student) =>
    student.name.toLowerCase().includes(query) ||
    student.roll.toLowerCase().includes(query)
  );

  emptyMessage.style.display = students.length === 0 ? "block" : "none";

  if (filtered.length === 0) {
    summaryTableBody.innerHTML = `<tr><td colspan="6">${students.length ? "No matching students found." : "Add a student to see the summary."}</td></tr>`;
    return;
  }

  summaryTableBody.innerHTML = filtered
    .slice()
    .sort((a, b) => a.roll.localeCompare(b.roll, undefined, { numeric: true }))
    .map((student) => {
      const counts = getCounts(student);
      const percentageText = counts.total ? `${counts.percentage.toFixed(1)}%` : "0.0%";
      return `
        <tr>
          <td>${escapeHtml(student.roll)}</td>
          <td>${escapeHtml(student.name)}</td>
          <td>${counts.present}</td>
          <td>${counts.absent}</td>
          <td class="percentage">
            ${percentageText}
            <div class="progress" aria-label="Attendance percentage">
              <span style="width: ${counts.percentage}%"></span>
            </div>
          </td>
          <td>
            <button class="btn secondary small-btn" data-action="edit" data-id="${escapeHtml(student.id)}">Edit</button>
            <button class="btn danger small-btn" data-action="delete" data-id="${escapeHtml(student.id)}">Delete</button>
          </td>
        </tr>`;
    }).join("");
}
