# Attendance Manager

A beginner-friendly student attendance tracker built with HTML, CSS, and JavaScript.

## Folder structure

```text
attendance_manager/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── app.js
└── README.md
```

## How to run

1. Extract the folder or ZIP file.
2. Open `index.html` in Chrome, Edge, Firefox, or another modern browser.
3. Add students, select a date, and choose Present or Absent in the attendance dropdown.
4. Data is saved automatically in your browser's local storage.

## Notes

- Roll numbers must be unique.
- Attendance percentage = Present days ÷ (Present days + Absent days) × 100.
- Data stays in the browser on this device. Clearing browser site data or switching browsers/devices may remove or hide the saved records.
- This is a basic local-only demo; it does not include user accounts, cloud sync, or a shared database.
